# Todo list

### Home page 
includes : small intro text / server list using API / donations / discord link